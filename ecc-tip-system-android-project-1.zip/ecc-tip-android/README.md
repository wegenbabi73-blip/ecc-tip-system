# ECC Tip System — Android Project

ይህ ፕሮጀክት የተጠናቀቀውን `www/index.html` ወደ Android app ለመጠቀም Capacitor መዋቅር ነው።

## 1. Requirements
- Node.js
- Android Studio
- Android SDK
- JDK 17 (የአካባቢዎ Capacitor/Android Gradle ማዋቀር ጋር የሚስማማ)

## 2. Install
```bash
npm install
npx cap add android
npx cap sync android
```

## 3. Open Android Studio
```bash
npx cap open android
```

## 4. Build APK
Android Studio ውስጥ:
Build → Build Bundle(s) / APK(s) → Build APK(s)

## Important security note
ይህ የdemo frontend ነው። `localStorage` ውስጥ የሚቀመጥ መረጃ ለእውነተኛ ሚስጥራዊ/የመንግስት ስርዓት በቂ ደህንነት አይሰጥም። እውነተኛ deployment ከመደረጉ በፊት backend, authentication/MFA, RBAC, HTTPS/TLS, encryption at rest, audit logs, secure file storage, malware scanning, rate limiting, backups እና key management ያስፈልጋሉ።
