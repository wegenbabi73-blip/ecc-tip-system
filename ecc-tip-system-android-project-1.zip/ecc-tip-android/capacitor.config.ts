import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ecc.tipsystem',
  appName: 'ECC Tip System',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
